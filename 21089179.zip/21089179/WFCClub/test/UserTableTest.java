/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;



import java.awt.Component;

import javax.swing.JButton;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class UserTableTest {

    @Test
    public void testJButton1ActionPerformed() {
        // create a mock object of the Admindashboard class
        Admindashboard admindashboardMock = Mockito.mock(Admindashboard.class);

        // create an instance of the UserTable class
        UserTable userTable = new UserTable();

        // set the Admindashboard mock object as the ActionListener for the jButton1 button
        Component[] components = userTable.getContentPane().getComponents();
        for (Component component : components) {
            if (component instanceof JButton) {
                JButton jButton = (JButton) component;
                if (jButton.getText().equals("Back")) {
                    jButton.addActionListener(e -> admindashboardMock.setVisible(true));
                }
            }
        }

        // click the jButton1 button
        components = userTable.getContentPane().getComponents();
        for (Component component : components) {
            if (component instanceof JButton) {
                JButton jButton = (JButton) component;
                if (jButton.getText().equals("Back")) {
                    jButton.doClick();
                }
            }
        }

        // assert that the Admindashboard mock object is set to visible
        Mockito.verify(admindashboardMock, Mockito.times(1)).setVisible(true);
    }
}

