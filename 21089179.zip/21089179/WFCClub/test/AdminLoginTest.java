/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;



import javax.swing.*;
import java.awt.event.ActionEvent;



public class AdminLoginTest {
    @Test
    public void testSubmitButton() {
        AdminLogin adminLogin = new AdminLogin();
        adminLogin.jTextField1.setText("admin");
        adminLogin.jPasswordField1.setText("password");

        adminLogin.jButton1.doClick();

        Assertions.assertEquals("admin", adminLogin.jTextField1.getText());
        Assertions.assertEquals("password", adminLogin.jPasswordField1.getText());

        // Add further tests to check the functionality of the Submit button
    }

    @Test
    public void testBackButton() {
        AdminLogin adminLogin = new AdminLogin();

        adminLogin.jButton2.doClick();

        // Add further tests to check the functionality of the Back button
    }
}


