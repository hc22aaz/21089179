/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


import java.awt.event.ActionEvent;
import javax.swing.JButton;

public class UserdashboardTest {

    @Test
    public void testJButton3ActionPerformed() {
        Userdashboard instance = new Userdashboard();
        JButton jButton3 = new JButton();
        ActionEvent e = new ActionEvent(jButton3, ActionEvent.ACTION_PERFORMED, "jButton3");
        instance.jButton3ActionPerformed(e);
        String expected = "Viewing timetable by day...";
        String actual = JOptionPane.getRootFrame().getComponents()[0].toString();
        assertEquals(expected, actual);
    }
}

