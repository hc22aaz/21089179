/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.Test;
import org.junit.Assert;

public class SaturdayTableTest {
    
    @Test
    public void testBackButton() {
        SaturdayTable table = new SaturdayTable();
        table.setVisible(true);
        
        // Click the "Back" button
        JButton backButton = (JButton) TestUtils.getChildNamed(table, "Back");
        backButton.doClick();
        
        // Check that the "LessonByDay" frame is visible
        LessonByDay frame = (LessonByDay) TestUtils.getFrame("LessonByDay");
        Assert.assertTrue(frame.isVisible());
        
        // Close the frames
        frame.dispose();
        table.dispose();
    }
    
}
