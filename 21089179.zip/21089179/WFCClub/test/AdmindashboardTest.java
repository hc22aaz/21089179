/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import javax.swing.JButton;
import javax.swing.JOptionPane;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/import org.junit.Test;
import java.awt.event.ActionEvent;
import javax.swing.JButton;

import static org.junit.Assert.assertEquals;

public class AdmindashboardTest {

    @Test
    public void testButtonActionPerformed() {
        Admindashboard adminDashboard = new Admindashboard();
        JButton jButton3 = new JButton();
        jButton3.setText("View Users");
        jButton3.addActionListener(adminDashboard);

        jButton3.doClick();
        String expectedMessage = "View Users";
        String message = (String) JOptionPane.getRootFrame().getGlassPane().getClientProperty("message");

        assertEquals(expectedMessage, message);
    }
}
