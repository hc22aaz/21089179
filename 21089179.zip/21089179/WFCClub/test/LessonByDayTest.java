/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.awt.event.ActionEvent;

public class LessonByDayTest {

    @Test
    public void testSaturdayButton() {
        LessonByDay instance = new LessonByDay();
        JButton saturdayButton = (JButton) TestHelper.getChildNamed(instance, "jButton3");
        assertNotNull(saturdayButton);

        // Perform a click on the button
        saturdayButton.getActionListeners()[0].actionPerformed(new ActionEvent(this, ActionEvent.ACTION_PERFORMED, null));

        // Check that a JOptionPane with "Saturday Lessons" message is displayed
        assertEquals("Saturday Lessons", TestHelper.getOptionPaneMessage());
    }

}
