/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import static org.junit.Assert.assertEquals;
import org.junit.Test;
import org.mockito.Mockito;

public class BodysculptTableTest {
    
    @Test
    public void testBackButton() {
        BodysculptTable bodysculptTable = Mockito.spy(new BodysculptTable());
        bodysculptTable.setVisible(true);
        
        // Simulate a click on the "Back" button
        bodysculptTable.jButton1.doClick();
        
        // Verify that the BodysculptTable is not visible anymore and a new LessonByType screen is opened
        Mockito.verify(bodysculptTable, Mockito.times(1)).hide();
        Mockito.verify(bodysculptTable, Mockito.times(1)).dispose();
        Mockito.verifyNoMoreInteractions(bodysculptTable);
    }
}

