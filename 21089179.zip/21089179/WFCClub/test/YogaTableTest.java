/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

@RunWith(JUnit4.class)
public class YogaTableTest {
    
    private YogaTable yogaTable;
    private JButton backButton;
    
    @BeforeEach
    public void setUp() {
        yogaTable = new YogaTable();
        Component[] components = yogaTable.getContentPane().getComponents();
        for (Component component : components) {
            if (component instanceof JPanel) {
                JPanel panel = (JPanel) component;
                Component[] innerComponents = panel.getComponents();
                for (Component innerComponent : innerComponents) {
                    if (innerComponent instanceof JButton) {
                        JButton button = (JButton) innerComponent;
                        if (button.getText().equals("Back")) {
                            backButton = button;
                        }
                    }
                }
            }
        }
    }
    
    @Test
    public void backButtonExists() {
        assertNotNull(backButton);
    }
    
    @Test
    public void backButtonHasListener() {
        ActionListener[] listeners = backButton.getActionListeners();
        assertTrue(listeners.length > 0);
    }
    
    @Test
    public void backButtonShowsCorrectScreen() {
        backButton.doClick();
        assertFalse(yogaTable.isVisible());
        assertTrue(yogaTable.getParent() instanceof LessonByType);
    }
    
}

