/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

import java.awt.Component;
import java.awt.Container;
import java.awt.event.ActionEvent;

import javax.swing.JButton;
import javax.swing.JPanel;

public class LessonByTypeTest {
    
    @Test
    public void testButtonFunctionality() {
        LessonByType lessonByType = new LessonByType();
        lessonByType.setVisible(true);
        
        Container container = lessonByType.getContentPane();
        
        Component[] components = container.getComponents();
        for (Component component : components) {
            if (component instanceof JPanel) {
                JButton[] buttons = ((JPanel) component).getComponents();
                for (JButton button : buttons) {
                    button.doClick();
                    assertTrue(button.isEnabled(), "Button was not enabled after being clicked");
                }
            }
        }
    }
}

