/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;




import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.Field;
import javax.swing.JButton;

public class RatingTableTest {

  @Test
  public void testButtonActionPerformed() throws Exception {
    RatingTable ratingTable = new RatingTable();
    ratingTable.setVisible(true);

    JButton jButton1 = null;
    for (Field field : RatingTable.class.getDeclaredFields()) {
      if (field.getName().equals("jButton1")) {
        field.setAccessible(true);
        jButton1 = (JButton) field.get(ratingTable);
        break;
      }
    }

    Assertions.assertNotNull(jButton1);

    boolean actionPerformed = false;
    for (ActionListener actionListener : jButton1.getActionListeners()) {
      actionListener.actionPerformed(new ActionEvent(jButton1, ActionEvent.ACTION_PERFORMED, null));
      actionPerformed = true;
    }

    Assert.assertTrue(actionPerformed);
  }

}

