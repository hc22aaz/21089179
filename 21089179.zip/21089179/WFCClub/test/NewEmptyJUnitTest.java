/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.*;
import static org.junit.Assert.*;
import org.fest.swing.fixture.*;

public class ZumbaTableTest {

    private FrameFixture window;

    @BeforeEachs
    public void setUp() {
        ZumbaTable frame = new ZumbaTable();
        window = new FrameFixture(frame);
        window.show();
    }

    @AfterEach
    public void tearDown() {
        window.cleanUp();
    }

    @Test
    public void testBackButton() {
        // Click the "Back" button
        window.button("jButton1").click();

        // Verify that the previous window (LessonByType) is visible
        assertTrue(window.frame().getTitle().equals("Choose a Lesson Type"));
    }
}

