/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


import static org.junit.Assert.*;
import java.awt.event.ActionEvent;

public class SpinTableTest {
    private SpinTable spinTable;
    
    @BeforeEach
    public void setUp() {
        spinTable = new SpinTable();
    }
    
    @Test
    public void testBackButton() {
        // click the back button
        spinTable.jButton1ActionPerformed(new ActionEvent(this, ActionEvent.ACTION_PERFORMED, null));
        
        // assert that a new instance of LessonByType is created and it's visible
        LessonByType lessonByType = new LessonByType();
        assertFalse(spinTable.isVisible());
        assertTrue(lessonByType.isVisible());
    }
}

