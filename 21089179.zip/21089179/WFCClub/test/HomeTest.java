/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


import java.awt.Component;
import java.awt.Container;

public class HomeTest {
    private Home home;
    private javax.swing.JButton userLoginButton;
    private javax.swing.JButton adminLoginButton;
    
    @BeforeEach
    public void setUp() {
        home = new Home();
        userLoginButton = (javax.swing.JButton)findComponentByName(home, "jButton1");
        adminLoginButton = (javax.swing.JButton)findComponentByName(home, "jButton2");
    }
    
    @Test
    public void testUserLoginButton() {
        // simulate a click on the user login button
        userLoginButton.doClick();
        
        // check if the UserLogin window is displayed
        assertEquals(true, home.isVisible());
        assertEquals(false, userLoginButton.isVisible());
        assertEquals(false, adminLoginButton.isVisible());
    }
    
    @Test
    public void testAdminLoginButton() {
        // simulate a click on the admin login button
        adminLoginButton.doClick();
        
        // check if the AdminLogin window is displayed
        assertEquals(true, home.isVisible());
        assertEquals(false, userLoginButton.isVisible());
        assertEquals(false, adminLoginButton.isVisible());
    }
    
    // helper method to find a component by name
    public Component findComponentByName(Container container, String name) {
        for (Component component : container.getComponents()) {
            if (name.equals(component.getName())) {
                return component;
            }
            
            if (component instanceof Container) {
                Component child = findComponentByName((Container)component, name);
                if (child != null) {
                    return child;
                }
            }
        }
        
        return null;
    }
}
