/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;



import java.util.ArrayList;
import java.util.List;

public class AdminBookingsTableTest {
    @Test
    public void testBookingTableModel() {
        Booking b1 = new Booking("user1", "lesson1", "monday", "10:00", "week1");
        Booking b2 = new Booking("user2", "lesson2", "tuesday", "14:00", "week2");
        List<Booking> bookings = new ArrayList<>();
        bookings.add(b1);
        bookings.add(b2);
        BookingTableModel model = new BookingTableModel(bookings);
        assertEquals(2, model.getRowCount());
        assertEquals("username", model.getColumnName(0));
        assertEquals("Lesson", model.getColumnName(1));
        assertEquals("day", model.getColumnName(2));
        assertEquals("timeslot", model.getColumnName(3));
        assertEquals("week", model.getColumnName(4));
        assertEquals("user1", model.getValueAt(0, 0));
        assertEquals("lesson1", model.getValueAt(0, 1));
        assertEquals("monday", model.getValueAt(0, 2));
        assertEquals("10:00", model.getValueAt(0, 3));
        assertEquals("week1", model.getValueAt(0, 4));
        assertEquals("user2", model.getValueAt(1, 0));
        assertEquals("lesson2", model.getValueAt(1, 1));
        assertEquals("tuesday", model.getValueAt(1, 2));
        assertEquals("14:00", model.getValueAt(1, 3));
        assertEquals("week2", model.getValueAt(1, 4));
    }
}


