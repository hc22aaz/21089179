/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


import java.awt.Component;
import java.awt.event.ActionEvent;

public class UserBookingsTableTest {

    private UserBookingsTable frame;

    @BeforeEach
    public void setUp() {
        frame = new UserBookingsTable();
        frame.setVisible(true);
    }

    @Test
    public void testBackButton() {
        Component[] components = frame.getContentPane().getComponents();
        for (Component component : components) {
            if (component instanceof javax.swing.JButton) {
                javax.swing.JButton button = (javax.swing.JButton) component;
                if (button.getText().equals("Back")) {
                    button.doClick();
                    assertFalse("Frame should be hidden", frame.isVisible());
                    return;
                }
            }
        }
        fail("Back button not found");
    }
}

