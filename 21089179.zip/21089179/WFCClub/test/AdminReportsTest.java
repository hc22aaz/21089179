/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.Test;
import static org.junit.Assert.*;

public class AdminReportsTest {
    
    @Test
    public void testBackButton() {
        AdminReports adminReports = new AdminReports();
        adminReports.setVisible(true);
        
        // simulate clicking the button
        adminReports.jButton1.doClick();
        
        // check if the new window is visible and the old one is hidden
        assertFalse(adminReports.isVisible());
        assertTrue(new Admindashboard().isVisible());
    }
    
}
