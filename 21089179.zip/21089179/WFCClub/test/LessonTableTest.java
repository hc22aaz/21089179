/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;



public class LessonTableTest {
    
    private LessonTable lessonTable;
    
    @BeforeEach
    public void setUp() {
        lessonTable = new LessonTable();
        lessonTable.setVisible(true);
    }
    
    @AfterEach
    public void tearDown() {
        lessonTable.dispose();
    }

    @Test
    public void testBackButton() {
        assertNotNull(lessonTable.jButton1);
        assertTrue(lessonTable.jButton1.isEnabled());
        
        lessonTable.jButton1.doClick();
        assertFalse(lessonTable.isVisible());
    }
    
}

