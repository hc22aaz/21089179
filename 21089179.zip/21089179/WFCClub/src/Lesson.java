/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.util.ArrayList;
import java.util.List;

public class Lesson {
    public enum Type {
        SPIN,
        YOGA,
        BODYSCULPT,
        ZUMBA
    }

    private Type type;
    private int capacity;
    private String day;
    private String timeSlot;
    private double price;
    private int week;

    private static List<Lesson> lessonList = new ArrayList<>();
    

    public Lesson(Type type, int capacity, String day, String timeSlot, double price, int week) {
        this.type = type;
        this.capacity = capacity;
        this.day = day;
        this.timeSlot = timeSlot;
        this.price = price;
        this.week = week;
        lessonList.add(this);
    }

    public Type getType() {
        return type;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public String getDay() {
        return day;
    }

    public String getTimeSlot() {
        return timeSlot;
    }

    public double getPrice() {
        return price;
    }

    public int getWeek() {
        return week;
    }

    public static List<Lesson> getLessonList() {
        return lessonList;
    }

    static {
        // Initialize the list of lessons with their types, capacities, days, times, prices, and weeks
        for (int week = 1; week <= 10; week++) {
            new Lesson(Type.SPIN, 5, "Saturday", "Morning", 10.0, week);
            new Lesson(Type.YOGA, 5, "Saturday", "Evening", 15.0, week);
            new Lesson(Type.BODYSCULPT, 5, "Sunday", "Morning", 12.0, week);
            new Lesson(Type.ZUMBA, 5, "Sunday", "Evening", 8.0, week);
            
        }
    }
    
    public static List<Lesson> getSPINLessons() {
        List<Lesson> spinLessons = new ArrayList<>();
        for (Lesson lesson : lessonList) {
            if (lesson.getType()==(Type.SPIN)) {
                spinLessons.add(lesson);
            }
        }
        return spinLessons;
    }
    
    public static List<Lesson> getYOGALessons() {
        List<Lesson> yogaLessons = new ArrayList<>();
        for (Lesson lesson : lessonList) {
            if (lesson.getType()==Type.YOGA) {
                yogaLessons.add(lesson);
            }
        }
        return yogaLessons;
    }
    
    public static List<Lesson> getBODYSCULPTLessons() {
        List<Lesson> bodysculptLessons = new ArrayList<>();
        for (Lesson lesson : lessonList) {
            if (lesson.getType()==Type.BODYSCULPT) {
                bodysculptLessons.add(lesson);
            }
        }
        return bodysculptLessons;
    }
    
    public static List<Lesson> getZUMBALessons() {
        List<Lesson> zumbaLessons = new ArrayList<>();
        for (Lesson lesson : lessonList) {
            if (lesson.getType()==Type.ZUMBA) {
                zumbaLessons.add(lesson);
            }
        }
        return zumbaLessons;
    }
    
    public static List<Lesson> getSATURDAYDay() {
    List<Lesson> saturdayDay = new ArrayList<>();
    for (Lesson lesson : lessonList) {
        if (lesson.getDay().equals("Saturday")) {
            saturdayDay.add(lesson);
        }
    }
    return saturdayDay;
}
    
    public static List<Lesson> getSUNDAYDay() {
        List<Lesson> sundayDay = new ArrayList<>();
        for (Lesson lesson : lessonList) {
            if (lesson.getDay().equals("Sunday")) {
                sundayDay.add(lesson);
            }
        }
        return sundayDay;
    }
    
    public static Lesson getLessonByName(Type lessonName, List<Lesson> lessons) {
        for (Lesson lesson : lessons) {
            if (lesson.getType()==lessonName) {
                return lesson;
            }
        }
        return null;
    }
}
