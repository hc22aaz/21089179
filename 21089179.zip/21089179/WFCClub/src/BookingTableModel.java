import java.util.List;
import javax.swing.table.AbstractTableModel;

public class BookingTableModel extends AbstractTableModel {
	private final String[] columnNames = { "username", "Lesson", "day", "timeslot", "week" };
	private final List<Booking> bookingList;

	public BookingTableModel(List<Booking> bookingList) {
		this.bookingList = bookingList;
	}

	@Override
	public int getRowCount() {
		return bookingList.size();
	}

	@Override
	public int getColumnCount() {
		return columnNames.length;
	}

	@Override
	public String getColumnName(int column) {
		return columnNames[column];
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		Booking booking = bookingList.get(rowIndex);
		switch (columnIndex) {
		case 0:
			return booking.getUsername();
		case 1:
			return booking.getLesson();
		case 2:
			return booking.getDay();
		case 3:
			return booking.getTimeSlot();
		case 4:
			return booking.getWeek();
		default:
			return null;
		}
	}
}
