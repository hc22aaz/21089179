/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


import java.util.ArrayList;
import java.util.List;

public class Rating {
    private String lesson;
    private Double rating;
    private static List<Rating> ratingList = new ArrayList<>();

    public Rating(String lesson, Double rating) {
        this.lesson = lesson;
        this.rating = rating;
        ratingList.add(this);
    }

    public String getLesson() {
        return lesson;
    }

    public double getRating() {
        return rating;
    }

    public static List<Rating> getRatingList() {
        return ratingList;
    }

    // Hardcoding 5 users with their name as their password
    static {
        new Rating("SPIN", 5.00);
        new Rating("YOGA", 5.00);
        new Rating("BODYSCULPT", 5.00);
        new Rating("ZUMBA", 5.00);
    }
}

