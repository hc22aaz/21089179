import java.util.List;
import javax.swing.table.AbstractTableModel;

public class RatingTableModel extends AbstractTableModel {
    private final String[] columnNames = {"lesson", "rating"};
    private final List<Rating> ratingList;

    public RatingTableModel(List<Rating> ratingList) {
        this.ratingList = ratingList;
    }

    @Override
    public int getRowCount() {
        return ratingList.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Rating rating = ratingList.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return rating.getLesson();
            case 1:
                return rating.getRating();
            default:
                return null;
        }
    }
}
