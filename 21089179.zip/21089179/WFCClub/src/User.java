/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


import java.util.ArrayList;
import java.util.List;

public class User {
    private String username;
    private String password;
    private static List<User> userList = new ArrayList<>();
    private static String currentUName;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
        userList.add(this);
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public static List<User> getUserList() 
    {
        return userList;
    }
    
    
    

    // Hardcoding 5 users with their name as their password
    static {
        new User("Harish", "Harish");
        new User("Umesh", "Umesh");
        new User("Mani", "Mani");
        new User("Sampath", "Sampath");
        new User("Ajay", "Ajay");
    }
    
    public static void setCurrentUName(String uname)
    {
    	currentUName = uname;
    }
    
    public static String getUserName()
    {
    	return currentUName;
    }
}

