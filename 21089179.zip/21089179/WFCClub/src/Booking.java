/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.util.ArrayList;
import java.util.List;

public class Booking {
    

    private String username;
    private String Lesson;
    
    private String day;
    private String timeSlot;
    private String week;

    private static List<Booking> bookingList = new ArrayList<>();
    

    public Booking(String username, String Lesson, String day, String timeSlot, String week) {
        this.username = username;
        this.Lesson = Lesson;
        this.day = day;
        this.timeSlot = timeSlot;
        
        this.week = week;
        bookingList.add(this);
    }

    public String getUsername() {
        return username;
    }

    public String getLesson() {
        return Lesson;
    }

    

    public String getDay() {
        return day;
    }

    public String getTimeSlot() {
        return timeSlot;
    }

    

    public String getWeek() {
        return week;
    }

    public static List<Booking> getBookingList() 
    {
        return getUserBookings(User.getUserName());
    }
    
    public static void deleteBooking(String username, String lesson, String day, String timeSlot, String week) 
    {
    for (Booking booking : bookingList) {
        if (booking.getUsername().equals(username) && booking.getLesson().equals(lesson) &&
            booking.getDay().equals(day) && booking.getTimeSlot().equals(timeSlot) && 
            booking.getWeek().equals(week)) {
            bookingList.remove(booking);
            break;
        }
    }
}


    
    
    public static List<Booking> getUserBookings(String username)  
    {
    	if(username.equals("admin"))
    		return bookingList;
    	
        List<Booking> userBookings = new ArrayList<>();
        for (Booking booking : bookingList) {
            if (booking.getUsername().equals(username)) {
                userBookings.add(booking);
            }
        }
        return userBookings;
    }
    
    
}
